class StateSpaceModel(object):
    """
    Base class for state-space models
    """
    pass
